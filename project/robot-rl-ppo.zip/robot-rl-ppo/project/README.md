# 连续动作实战：MuJoCo + PPO

这个练习是浏览器入门实验的进阶版：用 MuJoCo 模拟倒立摆，用 PPO 训练输出连续推力的策略，做独立评估，保存模型，再导出并验证 ONNX。它**不会连接或控制真实硬件**。

浏览器实验使用的是另一套离散动作 DQN；两者任务相似，但模型、动作、观察的顺序、奖励及训练算法都不完全相同，不能互换模型或直接比较分数。

## 学完能得到什么

1. 一份真实训练出的 `ppo_pendulum.zip` 策略。
2. 一份记录训练预算、依赖版本、随机策略和独立测试结果的 `evaluation.json`。
3. 一个经过数值对照的 `policy.onnx`，以及验证记录 `policy.verification.json`。
4. 一套可迁移的方法：明确输入输出契约、比较基线、独立测试、检查导出前后是否一致。

## 1. 建立环境

下面以 Windows 10/11、64 位电脑和 PowerShell 为例。网页实验不需要安装；只有从这里开始运行 Python 进阶工程时才需要以下准备。首次安装依赖需要联网和一定的磁盘空间；本例用 CPU，不要求 NVIDIA 显卡。

1. 在课程网站的“参考资料”中下载“实战代码”，在下载的 ZIP 上点击右键，选择“全部解压”。逐层打开解压后的 `robot-rl-ppo/project/`，直到同一窗口里能看到 `train_ppo.py` 和 `requirements.txt`。不要直接在 ZIP 压缩包内部运行。
2. 在这个文件夹的地址栏输入 `powershell` 并回车。新窗口打开后执行下面两行：第一行显示当前目录，第二行应显示 `True`。若显示 `False`，说明终端没有打开在上一步的文件夹里，重新按上一步操作。

```powershell
Get-Location
Test-Path .\train_ppo.py
```

3. 在同一窗口执行 `python --version`。建议使用 **64 位 Python 3.13**；本课程在 Windows、Python 3.13.12 上测试过。若没有 Python，可从 [Python 3.13 官方 Windows 下载页](https://www.python.org/downloads/windows/)选择 Python 3.13 的 **Windows installer (64-bit)**；安装时勾选“Add Python to PATH”，完成后关闭并重新打开 PowerShell，再运行 `python --version`。若系统已有多个 Python 版本，确认本窗口实际显示 `Python 3.13.x`；不要把其他版本当作已经验证过。
4. 创建只属于本项目的虚拟环境并安装依赖。第一条成功后会在当前文件夹出现 `.venv`；第二条需要下载依赖，结束时应看到 `Successfully installed` 或已满足依赖的提示。下面直接调用虚拟环境中的 Python，**无需激活环境，也无需修改 PowerShell 执行策略**。

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m pip check
```

`pip check` 显示 `No broken requirements found` 表示依赖检查通过；下载失败或提示找不到文件时先核对网络和当前目录，不要继续训练。macOS/Linux 可以改用 `.venv/bin/python`；安装及图形窗口的表现可能不同，本教程的完整跟练以 Windows 64 位为例。

## 2. 训练并评估

```powershell
.\.venv\Scripts\python.exe train_ppo.py --steps 60000 --episodes 20
```

程序先用随机动作记录基线，再在仿真里训练 PPO，保存、重新加载策略，在与训练分开的 20 个初始条件下比较。SB3 按整批采样，实际交互步数可能略超过请求预算。运行时间和成绩取决于电脑、依赖与随机性；不保证每次完全相同或一定达到特定分数。

输出位于 `runs/pendulum/`。先读 `evaluation.json` 中的 `random_baseline` 与 `trained_policy`，再看每回合的分数、步数和结束方式。这里奖励每存活一步约为 1；回合达到 1000 步会被时间截断。强行把平均分理解为现实机器人的成功率是不对的。

## 3. 观看仿真

```powershell
.\.venv\Scripts\python.exe watch_ppo.py
```

打开 MuJoCo 窗口后观察训练后的策略。若在无图形界面的服务器或远程环境运行，窗口可能不可用，但上一步的无窗口训练和评估仍可进行。

## 4. 导出与检查

```powershell
.\.venv\Scripts\python.exe export_onnx.py
```

脚本把确定性 PPO 策略导出为 ONNX，并在 101 组输入上比较导出结果与 Stable-Baselines3 的 `predict`；数值偏差超出容差就报错。输出动作的限幅包含在 ONNX 内。

输入是 `float32`、形状 `[批量, 4]`，顺序为：小车位置（m）、杆角度（rad）、小车速度（m/s）、杆角速度（rad/s）；输出是小车推力（N），范围 `[-3, 3]`。真实硬件需要另外建立并验证自己的接口，这个倒立摆模型不能直接用于其他机器人。

## 5. 迁移到你的机器人

先完成课程的“迁移到机器人”接口表，阅读 [真实机器人实战工作手册](../content/真实机器人实战工作手册.md)。按顺序定义任务和能真实读取的观察、选择动作及控制模式、测量电机/传感器/延迟、建立模型、训练和独立评估，再分阶段做硬件验证。换主控时保持策略的输入输出契约，并重做接口适配与验证。

ONNX 只是模型文件；并不意味着任意单片机能运行它，也不包含通信、驱动、独立保护或急停。模型导出数值一致不等于真机安全或训练效果已得到验证。

## 参考

- [Gymnasium InvertedPendulum-v5 环境](https://gymnasium.farama.org/environments/mujoco/inverted_pendulum/)
- [Stable-Baselines3 PPO](https://stable-baselines3.readthedocs.io/en/master/modules/ppo.html)
- [Stable-Baselines3 的模型导出说明](https://stable-baselines3.readthedocs.io/en/master/guide/export.html)
- [MuJoCo 文档](https://mujoco.readthedocs.io/)
